package resources;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.util.List;
import java.util.Properties;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pojo.AddTransaction;

public class Utils {
	public static RequestSpecification req;
	public RequestSpecification requestSpecification() throws IOException {

		if(req==null) {
		PrintStream log = new PrintStream(new FileOutputStream("logResult.txt"));
		 req= new RequestSpecBuilder()
				 .setBaseUri(getGlobalValue("baseUrl"))
				 .addFilter(RequestLoggingFilter.logRequestTo(log))
				 .addFilter(ResponseLoggingFilter.logResponseTo(log))
				 .setContentType(ContentType.JSON).build();
		 
		return req;
	}
		return req;
	} 

	public static String getGlobalValue(String key) throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("C:\\Sameer\\WorkSpace_Project\\Anthem-New\\src\\test\\java\\resources\\global.properties");
		prop.load(fis);
		System.out.println("Key:" +key);
		return prop.getProperty(key);
	
	}

	/*
	 * Utility which will give any key value in json
	 */
	public String getJsonPath(Response response, String key) {
		String value = null;
		String resp = response.asString();
		
	try {
		JsonPath js = new JsonPath(resp);
		
		value=js.get(key);
		System.out.println("******** : " +value);
	}
//	catch(HttpStatusCodeException e) {
//		System.out.println("Exception : "+e);
//	}
	catch(Exception e) {
		System.out.println("Exception : "+e);
	}
		
		return value;
	}
	
	public static <T> List<T> csvToObject(String csvPath,Class pojoClass) {
		List<T> data = null;
		File file = new File(csvPath);
        // validate file
        if (file.exists()) {
            // parse CSV file to create a list of `User` objects
            try (Reader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {

                // create csv bean reader
                CsvToBean<T> csvToBean = new CsvToBeanBuilder<T>(reader)
                        .withType(pojoClass)
                        .withIgnoreLeadingWhiteSpace(true)
                        .build();

                // convert `CsvToBean` object to list of users
              
                data = csvToBean.parse();
            } catch (Exception ex) {
            	ex.printStackTrace();
            }
        }
		return data;
	}
	
	
}
