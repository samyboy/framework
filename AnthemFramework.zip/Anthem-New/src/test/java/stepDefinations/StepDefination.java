package stepDefinations;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.AddTransaction;
import resources.APIResources;

//import resources.TestDataBuild;
import resources.Utils;

public class StepDefination extends Utils {
	RequestSpecification res;
	ResponseSpecification resspec;
	Response response;
	//TestDataBuild data = new TestDataBuild();

	@Given("Add Accum Transaction Payload from CSV")
	public void add_accum_transaction_payload() throws IOException {
		// Write code here that turns the phrase above into concrete actions

		List <AddTransaction> summaryData =Utils.csvToObject("C:\\Sameer\\WorkSpace_Project\\Anthem-New\\RequestPayload.csv", AddTransaction.class);
		resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
	
		//res = given().spec(requestSpecification()).body(data.addAccumTransaction(accumName, memberContract, claimNetwork));
		/*
		 * Writing for loop for all the parameters from CSV: request payload
		 */
		for (AddTransaction transaction:summaryData) {
			res = given().spec(requestSpecification()).body(transaction);
			
			
		}
		
	}

	@When("user calls {string} with {string} http request")
	public void user_calls_with_http_request(String resource, String method) {
		// Write code here that turns the phrase above into concrete actions
		APIResources resourceAPI = APIResources.valueOf(resource);
		System.out.println(resourceAPI.getResource());
		resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		if(method.equalsIgnoreCase("POST"))
			response = res.when().post(resourceAPI.getResource());
			//response = res.when().post("/maps/api/place/add/json").then().spec(resspec).extract().response();
			else if(method.equalsIgnoreCase("GET"))
		response = res.when().get(resourceAPI.getResource());
		
	}

	@Then("the API call got success with status code {int}")
	public void the_api_call_got_success_with_status_code(Integer int1) {
		// Write code here that turns the phrase above into concrete actions
		// System.out.println("Response Code" +response.getStatusCode());
		assertEquals(200,response.getStatusCode());
	}

	@Then("{string} in response  body is {string}")
	public void in_response_body_is(String keyValue, String expectedValue) {
		// Write code here that turns the phrase above into concrete actions
	//	System.out.println("*****" +expectedValue);
		//System.out.println("^^^^^^" +getJsonPath(response, keyValue));
		assertEquals(getJsonPath(response, keyValue), expectedValue);

	}

}
